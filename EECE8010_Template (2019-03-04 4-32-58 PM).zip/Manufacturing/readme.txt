Readme.txt file for the Manufacturing directory.

Student Names:                Santhosh Nagendran
Student Numbers:              8272767
Phone Contact Information:    4379812425
Board Size:                   6 * 4 inches
